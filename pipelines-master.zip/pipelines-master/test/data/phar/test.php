<?php

/* this file is part of pipelines */

printf("%s\n", 'echo a hello from test.php');

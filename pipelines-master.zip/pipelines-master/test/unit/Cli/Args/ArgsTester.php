<?php

/* this file is part of pipelines */

namespace Ktomk\Pipelines\Cli\Args;

class ArgsTester extends Args
{
    public /** @noinspection PropertyInitializationFlawsInspection */
        $arguments = array();
}

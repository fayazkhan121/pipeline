<?php

/* this file is part of pipelines */

namespace Ktomk\Pipelines\Utility;

interface Runnable
{
    /**
     * @return mixed
     */
    public function run();
}

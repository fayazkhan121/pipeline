<?php

/* this file is part of pipelines */

namespace Ktomk\Pipelines\Cli\Args;

/**
 * Class Args
 *
 * Node of the family Tree
 */
class Args
{
    /**
     * @var array
     */
    protected $arguments = array();
}
